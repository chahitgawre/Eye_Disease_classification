# DR_Disease_Grading
Experimented different CNN Models ( with and without Attention Layers ) for training and testing of APTOS Dataset for Classification.  For more enhancement , here is the implementation of DCGAN Model of fundus images for augmentation purpose for expansion of the dataset and the variations in the images to improve accuracy.
